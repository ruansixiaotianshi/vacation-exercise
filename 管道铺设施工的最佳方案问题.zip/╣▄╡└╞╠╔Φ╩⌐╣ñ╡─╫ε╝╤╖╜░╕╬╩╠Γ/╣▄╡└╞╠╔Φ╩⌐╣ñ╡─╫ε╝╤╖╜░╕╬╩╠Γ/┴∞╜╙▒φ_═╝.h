#pragma once
#include <iostream>
#include <fstream>
#include <windows.h>
#include "˳��ջ.h"
using namespace std;

#define MaxVerNum 100
typedef char VertexType;
typedef int EdgeType;
typedef struct node {
	int adjvex;
	double info;
	struct node *next;
}EdgeNode;
typedef struct vnode {
	VertexType vertex;
	EdgeNode *firstedge;
}VertexNode;
typedef  VertexNode AdjList[MaxVerNum] ;
typedef struct {
	AdjList adjlist;
	int n, e;
}ALGraph;
void CreateALGraph(ALGraph *G) {
	int i, j, k;
	double info;
	EdgeNode *s;
	ifstream  infile("����.txt", ios::in | ios::_Nocreate);
	infile.setf(ios::skipws);//�����հ��ַ�����
	infile >> G->n >> G->e;//���붥�����ͱ���
	for (i = 0; i < G->n; i++) {
		infile >> G->adjlist[i].vertex;
		G->adjlist[i].firstedge = NULL;
	}
	for (k = 0; k < G->e; k++) {
		infile >> i >>info>> j;//�����Vi,Vj�Ķ����Ӧ���
		s = (EdgeNode*)malloc(sizeof(EdgeNode));
		s->adjvex = j;
		s->info = info;
		s->next = G->adjlist[i].firstedge;
		G->adjlist[i].firstedge = s;
	}
	infile.close();
}


static  void init_prim(ALGraph * graph, ALGraph * prim_tree)
{
	int i;
	for (i = 0; i < graph->n; i++)
	{
		prim_tree->adjlist[i].vertex = graph->adjlist[i].vertex;
		prim_tree->adjlist[i].firstedge = NULL;
	}
	prim_tree->n = graph->n;
	prim_tree->e = graph->n - 1;
}
void G_Prim(ALGraph * graph, ALGraph * prim_tree)
{
	bool visited[MaxVerNum];
	int rem[MaxVerNum];
	int head =0;
	int i,k, num=0;//j=0,�㷨��ʼԪ�ر��
	double power;
    int pos= head;
	EdgeNode * tmp;
	SqStack *pstack=Init_SeqStack();
	
	for (i = 0; i < graph->n; i++)
		visited[i] = false;
	init_prim(graph, prim_tree);

	visited[head] = true;//�㷨��ʼԪ�����
	rem[num] = head;
	
	do {
			power= _I32_MAX;
			for(i=0;i<=num;i++){
				tmp = graph->adjlist[rem[i]].firstedge;	
				while (tmp != NULL){
					if (power > tmp->info && !visited[tmp->adjvex]){
					power = tmp->info;
					pos = tmp->adjvex;
					k = i;
					}
				tmp = tmp->next;
				}
			}
			if (prim_tree->adjlist[rem[k]].firstedge == NULL)
			{
					prim_tree->adjlist[rem[k]].firstedge = (EdgeNode*)malloc(sizeof(EdgeNode));
					prim_tree->adjlist[rem[k]].firstedge->adjvex = pos;
					prim_tree->adjlist[rem[k]].firstedge->info = power;
					prim_tree->adjlist[rem[k]].firstedge->next = NULL;
			}
			else {
					tmp = prim_tree->adjlist[rem[k]].firstedge;
					prim_tree->adjlist[rem[k]].firstedge = (EdgeNode*)malloc(sizeof(EdgeNode));//ͷ�巨
					prim_tree->adjlist[rem[k]].firstedge->adjvex = pos;
					prim_tree->adjlist[rem[k]].firstedge->info = power;
					prim_tree->adjlist[rem[k]].firstedge->next = tmp;
			}
			if (prim_tree->adjlist[pos].firstedge == NULL)
			{
					prim_tree->adjlist[pos].firstedge = (EdgeNode*)malloc(sizeof(EdgeNode));
					prim_tree->adjlist[pos].firstedge->adjvex = rem[k];
					prim_tree->adjlist[pos].firstedge->info = power;
					prim_tree->adjlist[pos].firstedge->next = NULL;
			}
			else {
					tmp = prim_tree->adjlist[pos].firstedge;
					prim_tree->adjlist[pos].firstedge = (EdgeNode*)malloc(sizeof(EdgeNode));//ͷ�巨
					prim_tree->adjlist[pos].firstedge->adjvex = rem[k];
					prim_tree->adjlist[pos].firstedge->info = power;
					prim_tree->adjlist[pos].firstedge->next = tmp;
			}
				cout <<'('<< rem[k] << ',' << pos <<')'<< endl;
				visited[pos] = true;
				rem[++num] = pos;
		}
		
	while (num!=(graph->n-1));//j�ص���ʼλ�ã��㷨����
}


