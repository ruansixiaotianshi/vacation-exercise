#pragma once
#include <iostream>
#include <stdlib.h>
using namespace std;

typedef  int ElemType;

#define Stack_MaxSize 10

typedef struct stack {
	ElemType data[Stack_MaxSize];
	int top;
}SqStack;

SqStack *Init_SeqStack() {
	SqStack *s;
	s = (SqStack*)malloc(sizeof(SqStack));
	s->top = -1;
	return s;
}

int IsEmpty_SeqStack(SqStack*s) {
	if (s->top == -1)
		return 1;
	else
		return 0;
}

int Push_SeqStack(SqStack *s, ElemType x) {
	if (s->top == Stack_MaxSize - 1)
		return 0;
	else {
		s->top++;
		s->data[s->top] = x;
		return 1;
	}
}

int Pop_SeqStack(SqStack *s, ElemType & x){
	if (IsEmpty_SeqStack(s))
		return 0;
	else {
		x = s->data[s->top];
		s->top--;
		return 1;
	}
}

ElemType Top_SeqStack(SqStack *s) {
	if (!IsEmpty_SeqStack(s))
		return s->data[s->top];
}
